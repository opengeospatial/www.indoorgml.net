﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using IFC2IndoorGML.DataType;

namespace IFC2IndoorGML.Export
{
    public class Export
    {
        public Export()
        {

        }

        // export IndoorGML file
        public void ExportIndoorGML(String filePath, BoundedBy boundedBy, List<List<State>> statesAll, List<List<Transition>> transitionsAll)
        {
            // create xml object
            XmlTextWriter xmlTxtWrither = new XmlTextWriter(filePath, null);
            xmlTxtWrither.Formatting = Formatting.Indented;
            xmlTxtWrither.WriteStartDocument(true);

            // create comments
            xmlTxtWrither.WriteComment("IndoorGML Editor (Sinedit)");
            xmlTxtWrither.WriteComment("http://IndoorGML.net");

            // open root element - IndoorFeatures
            xmlTxtWrither.WriteStartElement("IndoorFeatures", null);
            xmlTxtWrither.WriteAttributeString("gml:id","IFS");

            // root's nameSpaces
            xmlTxtWrither.WriteAttributeString("xmlns", "gml", null, "http://www.opengis.net/gml/3.2");
            xmlTxtWrither.WriteAttributeString("xmlns", "xlink", null, "http://www.w3.org/1999/xlink");
            xmlTxtWrither.WriteAttributeString("xmlns", "xsi", null, "http://www.w3.org/2001/XMLSchema-instance");
            xmlTxtWrither.WriteAttributeString("xsi", "schemaLocation", null, "indoorCore http://stem.cs.pusan.ac.kr/schema/0_9_1/IndoorGMLCore.xsd");
            xmlTxtWrither.WriteAttributeString("xmlns", "indoorCore");

            // open MultiLayeredGraph
            xmlTxtWrither.WriteStartElement("MultiLayeredGraph", null);
            xmlTxtWrither.WriteAttributeString("id", "http://www.opengis.net/gml/3.2", "MLG");

            // open SpaceLayer
            xmlTxtWrither.WriteStartElement("spaceLayers", null);
            xmlTxtWrither.WriteAttributeString("id", "http://www.opengis.net/gml/3.2", "SLs1");

            // spaceLayerMember
            xmlTxtWrither.WriteStartElement("spaceLayerMember", null);

            //indoorcore:SpaceLayer
            xmlTxtWrither.WriteStartElement("SpaceLayer", null);
            xmlTxtWrither.WriteAttributeString("id", "http://www.opengis.net/gml/3.2", "SL1");

            int i = 0;


            // input state information
            // open nodes
            xmlTxtWrither.WriteStartElement("nodes", null);
            xmlTxtWrither.WriteAttributeString("id", "http://www.opengis.net/gml/3.2", "N");

            foreach (List<State> stateList in statesAll)
            {
                foreach (State state in stateList)
                {
                    // open stateMember
                    xmlTxtWrither.WriteStartElement("stateMember", null);

                    // open State
                    xmlTxtWrither.WriteStartElement("State", null);
                    xmlTxtWrither.WriteAttributeString("id", "http://www.opengis.net/gml/3.2", state.stateInfo.objectName);

                    // gml:name
                    xmlTxtWrither.WriteElementString("name", "http://www.opengis.net/gml/3.2", state.stateInfo.objectName);

                    // open connects
                    xmlTxtWrither.WriteStartElement("connects", null);
                    xmlTxtWrither.WriteAttributeString("id", "http://www.opengis.net/gml/3.2", "CON" + i.ToString());

                    foreach (List<Transition> tl in transitionsAll)
                    {
                        foreach (Transition tr in tl)
                        {
                            if (tr.state1.stateInfo.objectName == state.stateInfo.objectName || tr.state2.stateInfo.objectName == state.stateInfo.objectName)
                            {
                                // add transitionMember
                                xmlTxtWrither.WriteStartElement("transitionMember", null);
                                xmlTxtWrither.WriteAttributeString("href", "http://www.w3.org/1999/xlink", "#" + tr.transitionInfo.objectName);
                                xmlTxtWrither.WriteEndElement();
                            }
                        }
                    }
                    // close connects 
                    xmlTxtWrither.WriteEndElement();

                    // open geometry
                    xmlTxtWrither.WriteStartElement("geometry", null);
                    //gml:Point
                    xmlTxtWrither.WriteStartElement("Point", "http://www.opengis.net/gml/3.2");
                    xmlTxtWrither.WriteAttributeString("gml:id", "PT" + i.ToString());
                    //gml:pos
                    xmlTxtWrither.WriteElementString("pos", "http://www.opengis.net/gml/3.2", state.point.getX().ToString() + " " + state.point.getY().ToString() + " " + state.point.getZ().ToString());
                    // close gml:Point 
                    xmlTxtWrither.WriteEndElement();
                    // close geometry 
                    xmlTxtWrither.WriteEndElement();

                    // close State 
                    xmlTxtWrither.WriteEndElement();
                    // close stateMember 
                    xmlTxtWrither.WriteEndElement();
                    i++;
                }
            }
            // close nodes
            xmlTxtWrither.WriteEndElement();

            i = 0;

            // input transition information
            // edges
            xmlTxtWrither.WriteStartElement("edges", null);
            xmlTxtWrither.WriteAttributeString("id", "http://www.opengis.net/gml/3.2", "E");
            foreach (List<Transition> transitionList in transitionsAll)
            {
                foreach (Transition transition in transitionList)
                {
                    // open transitionMember
                    xmlTxtWrither.WriteStartElement("transitionMember", null);

                    // open Transition
                    xmlTxtWrither.WriteStartElement("Transition", null);
                    xmlTxtWrither.WriteAttributeString("id", "http://www.opengis.net/gml/3.2", transition.transitionInfo.objectName);

                    // gml:name
                    xmlTxtWrither.WriteElementString("gml:name", transition.transitionInfo.objectName);

                    // weight
                    xmlTxtWrither.WriteElementString("weight", "1");

                    // start
                    xmlTxtWrither.WriteStartElement("start", null);
                    xmlTxtWrither.WriteAttributeString("href", "http://www.w3.org/1999/xlink", "#" + transition.state1.stateInfo.objectName);
                    xmlTxtWrither.WriteEndElement();

                    // end
                    xmlTxtWrither.WriteStartElement("end", null);
                    xmlTxtWrither.WriteAttributeString("href", "http://www.w3.org/1999/xlink", "#" + transition.state2.stateInfo.objectName);
                    xmlTxtWrither.WriteEndElement();

                    // open geometry
                    xmlTxtWrither.WriteStartElement("geometry", null);

                    xmlTxtWrither.WriteStartElement("gml:LineString", null);
                    xmlTxtWrither.WriteAttributeString("id", "http://www.opengis.net/gml/3.2", "LS" + i.ToString());
                    //gml:pos
                    xmlTxtWrither.WriteElementString("pos", "http://www.opengis.net/gml/3.2", transition.state1.point.getX().ToString() + " " + transition.state1.point.getY().ToString() + " " + transition.state1.point.getZ().ToString());
                    xmlTxtWrither.WriteElementString("pos", "http://www.opengis.net/gml/3.2", transition.state2.point.getX().ToString() + " " + transition.state2.point.getY().ToString() + " " + transition.state2.point.getZ().ToString());

                    // close gml:LineString 
                    xmlTxtWrither.WriteEndElement();
                    // close geometry 
                    xmlTxtWrither.WriteEndElement();

                    // close Transition 
                    xmlTxtWrither.WriteEndElement();
                    // close transitionMember 
                    xmlTxtWrither.WriteEndElement();
                    i++;
                }
            }
            // close edges 
            xmlTxtWrither.WriteEndElement();

            // close indoorcore:SpaceLayer 
            xmlTxtWrither.WriteEndElement();
            // close spaceLayerMember 
            xmlTxtWrither.WriteEndElement();
            // close SpaceLayer 
            xmlTxtWrither.WriteEndElement();
            // close MultiLayeredGraph 
            xmlTxtWrither.WriteEndElement();
            // close root element - IndoorFeatures
            xmlTxtWrither.WriteEndElement();

            xmlTxtWrither.Flush();
            xmlTxtWrither.Close();
        }

        // export CityGML file for visualization
        public void ExportCityGML(String filePath, List<List<State>> statesAll, List<List<Transition>> transitionsAll)
        {

            String polyId = "PolyID_IndoorGML";
            int count = 0;

            // create xml object
            XmlTextWriter xmlTxtWrither = new XmlTextWriter(filePath, null);
            xmlTxtWrither.Formatting = Formatting.Indented;
            xmlTxtWrither.WriteStartDocument(true);


            // open root element
            xmlTxtWrither.WriteStartElement("CityModel", null);

            //  set root's namespaces
            xmlTxtWrither.WriteAttributeString("xmlns", "xsi", null, "http://www.w3.org/2001/XMLSchema-instance");
            xmlTxtWrither.WriteAttributeString("xsi", "schemaLocation", null, "http://www.opengis.net/citygml/1.0 http://schemas.opengis.net/citygml/1.0/cityGMLBase.xsd  http://www.opengis.net/citygml/appearance/1.0 http://schemas.opengis.net/citygml/appearance/1.0/appearance.xsd http://www.opengis.net/citygml/building/1.0 http://schemas.opengis.net/citygml/building/1.0/building.xsd");
            xmlTxtWrither.WriteAttributeString("xmlns", "core", null, "http://www.opengis.net/citygml/1.0");
            xmlTxtWrither.WriteAttributeString("xmlns", "http://www.opengis.net/citygml/profiles/base/1.0");
            xmlTxtWrither.WriteAttributeString("xmlns", "bldg", null, "http://www.opengis.net/citygml/building/1.0");
            xmlTxtWrither.WriteAttributeString("xmlns", "grp", null, "http://www.opengis.net/citygml/cityobjectgroup/1.0");
            xmlTxtWrither.WriteAttributeString("xmlns", "app", null, "http://www.opengis.net/citygml/appearance/1.0");
            xmlTxtWrither.WriteAttributeString("xmlns", "gml", null, "http://www.opengis.net/gml");
            xmlTxtWrither.WriteAttributeString("xmlns", "xAL", null, "urn:oasis:names:tc:ciq:xsdschema:xAL:2.0");
            xmlTxtWrither.WriteAttributeString("xmlns", "xlink", null, "http://www.w3.org/1999/xlink");

            // open boundedBy 
            xmlTxtWrither.WriteStartElement("gml", "boundedBy", null);

                // open Envelope
                xmlTxtWrither.WriteStartElement("gml", "Envelope", null);
                xmlTxtWrither.WriteAttributeString("srsDimension", "3");
                xmlTxtWrither.WriteAttributeString("srsName", "urn:adv:crs:ETRS89_UTM32");

                    // open lowerCorner 
                    xmlTxtWrither.WriteStartElement("gml", "lowerCorner", "445525.757287 5444894.867331 -2.68 ");
                    xmlTxtWrither.WriteAttributeString("srsDimension", "3");
                    //close lowerCorner
                    xmlTxtWrither.WriteEndElement();


                    // open upperCorenr
                    xmlTxtWrither.WriteStartElement("gml", "upperCorner", "445543.872562 5444913.369022 8.72 ");
                    xmlTxtWrither.WriteAttributeString("srsDimension", "3");
                    // close upperCorenr
                    xmlTxtWrither.WriteEndElement();
               
                // close Envelope
                xmlTxtWrither.WriteEndElement();

            // close boundedBy
            xmlTxtWrither.WriteEndElement();

            // open cityObjectMember
            xmlTxtWrither.WriteStartElement("core", "cityObjectMember", null);

            // open Building
            xmlTxtWrither.WriteStartElement("bldg", "Building", null);

            // open interiorRoom
            xmlTxtWrither.WriteStartElement("bldg", "interiorRoom", null);

            // open Room
            xmlTxtWrither.WriteStartElement("bldg", "Room", null);

            // open roomInstallation
            xmlTxtWrither.WriteStartElement("bldg", "roomInstallation", null);

            // open IntBuildingInstallation
            xmlTxtWrither.WriteStartElement("bldg", "IntBuildingInstallation", null);
            xmlTxtWrither.WriteAttributeString("gml", "id", null, "IndoorGML_State_Transition");

            // open lod4Geometry
            xmlTxtWrither.WriteStartElement("bldg", "lod4Geometry", null);

            // open MultiSurface
            xmlTxtWrither.WriteStartElement("gml", "MultiSurface", null);

            foreach (List<State> stateList in statesAll)
            {
                foreach (State state in stateList)
                {
                    List<LinearRing> list = cubeFactoryByState(state);

                    foreach (LinearRing lr in list)
                    {
                        // open surfaceMember
                        xmlTxtWrither.WriteStartElement("gml", "surfaceMember", null);

                        // open Polygon
                        xmlTxtWrither.WriteStartElement("gml", "Polygon", null);
                        xmlTxtWrither.WriteAttributeString("gml", "id", null, polyId + count);

                        // open exterior
                        xmlTxtWrither.WriteStartElement("gml", "exterior", null);

                        // open LinearRing
                        xmlTxtWrither.WriteStartElement("gml", "LinearRing", null);
                        xmlTxtWrither.WriteAttributeString("gml", "id", null, polyId + count + "_0");
                        count++;

                        foreach (Point3D point in lr.pointList)
                        {
                            xmlTxtWrither.WriteElementString("gml", "pos", null, point.getX() + " " + point.getY() + " " + point.getZ());
                        }

                        // close LinearRing
                        xmlTxtWrither.WriteEndElement();

                        // close exterior
                        xmlTxtWrither.WriteEndElement();

                        // close Polygon
                        xmlTxtWrither.WriteEndElement();

                        // close surfaceMember
                        xmlTxtWrither.WriteEndElement();
                    }
                }
            }
           
            foreach (List<Transition> transitionList in transitionsAll)
            {
               
                foreach (Transition transition in transitionList)
                {
                    List<LinearRing> list = cubeFactoryByTransition(transition);
                    int cc = 0;
                    foreach (LinearRing lr in list)
                    {
                        // open surfaceMember 
                        xmlTxtWrither.WriteStartElement("gml", "surfaceMember", null);

                        // open Polygon 
                        xmlTxtWrither.WriteStartElement("gml", "Polygon", null);
                        xmlTxtWrither.WriteAttributeString("gml", "id", null, polyId + count);

                        // open exterior 
                        xmlTxtWrither.WriteStartElement("gml", "exterior", null);

                        // open LinearRing 
                        xmlTxtWrither.WriteStartElement("gml", "LinearRing", null);
                        xmlTxtWrither.WriteAttributeString("gml", "id", null, polyId + count + "_0");
                        count++;

                        foreach (Point3D point in lr.pointList)
                        {
                            xmlTxtWrither.WriteElementString("gml", "pos", null, point.getX() + " " + point.getY() + " " + point.getZ());
                        }

                        // close LinearRing 
                        xmlTxtWrither.WriteEndElement();

                        // close exterior 
                        xmlTxtWrither.WriteEndElement();

                        // close Polygon 
                        xmlTxtWrither.WriteEndElement();

                        // close surfaceMember 
                        xmlTxtWrither.WriteEndElement();
                        cc++;
                    }
                    
                }
                
            }
            // close MultiSurface 
            xmlTxtWrither.WriteEndElement();

            // close lod4Geometry 
            xmlTxtWrither.WriteEndElement();

            // close IntBuildingInstallation 
            xmlTxtWrither.WriteEndElement();

            // close RoomInstallation 
            xmlTxtWrither.WriteEndElement();

            // close Room 
            xmlTxtWrither.WriteEndElement();

            // close  interiorRoom 
            xmlTxtWrither.WriteEndElement();

            // close Building 
            xmlTxtWrither.WriteEndElement();

            // close cityObjectMember 
            xmlTxtWrither.WriteEndElement();

            // close root element
            xmlTxtWrither.WriteEndElement();

            xmlTxtWrither.Flush();
            xmlTxtWrither.Close();

        }

        public List<LinearRing> cubeFactoryByState(State state)
        {
            double X = state.point.getX();
            double Y = state.point.getY();
            double Z = state.point.getZ();

            double bufferValue = 0.1;
            // citydb-ifc bufferValue = 100
            // citydb-ifc2,3 bufferValue = 1;

            //points
            Point3D p1 = new Point3D(X - bufferValue, Y - bufferValue, Z);
            Point3D p2 = new Point3D(X + bufferValue, Y - bufferValue, Z);
            Point3D p3 = new Point3D(X + bufferValue, Y + bufferValue, Z);
            Point3D p4 = new Point3D(X - bufferValue, Y + bufferValue, Z);
            Point3D p5 = new Point3D(X - bufferValue, Y - bufferValue, Z + bufferValue);
            Point3D p6 = new Point3D(X + bufferValue, Y - bufferValue, Z + bufferValue);
            Point3D p7 = new Point3D(X + bufferValue, Y + bufferValue, Z + bufferValue);
            Point3D p8 = new Point3D(X - bufferValue, Y + bufferValue, Z + bufferValue);

            return cubeMaker(p1, p2, p3, p4, p5, p6, p7, p8);

        }
        public List<LinearRing> cubeFactoryByTransition(Transition transition)
        {
            Point3D statePoint1 = transition.state1.point;
            Point3D statePoint2 = transition.state2.point;

            double X1 = transition.state1.point.getX();
            double Y1 = transition.state1.point.getY();
            double Z1 = transition.state1.point.getZ();

            double X2 = transition.state2.point.getX();
            double Y2 = transition.state2.point.getY();
            double Z2 = transition.state2.point.getZ();

            double bufferValue = 0.05;
            // citydb-ifc bufferValue = 50
            // citydb-ifc2,3 bufferValue = 0.5;
            if (Z1 == Z2)
            {
                double Z = Z1;

                Point3D innerP1 = getPointInLinefromLength(statePoint1, statePoint2, bufferValue);
                Point3D innerP2 = getPointInLinefromLength(statePoint2, statePoint1, bufferValue);

                Point3D p2D1 = rotatePoint(innerP1, statePoint1, 90);
                Point3D p2D2 = rotatePoint(innerP2, statePoint2, 270);
                Point3D p2D3 = rotatePoint(innerP2, statePoint2, 90);
                Point3D p2D4 = rotatePoint(innerP1, statePoint1, 270);

                Point3D p1 = new Point3D(p2D1.getX(), p2D1.getY(), Z);
                Point3D p2 = new Point3D(p2D2.getX(), p2D2.getY(), Z);
                Point3D p3 = new Point3D(p2D3.getX(), p2D3.getY(), Z);
                Point3D p4 = new Point3D(p2D4.getX(), p2D4.getY(), Z);
                Point3D p5 = new Point3D(p2D1.getX(), p2D1.getY(), Z + bufferValue);
                Point3D p6 = new Point3D(p2D2.getX(), p2D2.getY(), Z + bufferValue);
                Point3D p7 = new Point3D(p2D3.getX(), p2D3.getY(), Z + bufferValue);
                Point3D p8 = new Point3D(p2D4.getX(), p2D4.getY(), Z + bufferValue);

                return cubeMaker(p1, p2, p3, p4, p5, p6, p7, p8);
            }
            else
            {
                Point3D p1 = new Point3D(X1 - bufferValue, Y1 - bufferValue, Z1);
                Point3D p2 = new Point3D(X1 + bufferValue, Y1 - bufferValue, Z1);
                Point3D p3 = new Point3D(X1 + bufferValue, Y1 + bufferValue, Z1);
                Point3D p4 = new Point3D(X1 - bufferValue, Y1 + bufferValue, Z1);
                Point3D p5 = new Point3D(X2 - bufferValue, Y2 - bufferValue, Z2);
                Point3D p6 = new Point3D(X2 + bufferValue, Y2 - bufferValue, Z2);
                Point3D p7 = new Point3D(X2 + bufferValue, Y2 + bufferValue, Z2);
                Point3D p8 = new Point3D(X2 - bufferValue, Y2 + bufferValue, Z2);

                return cubeMaker(p1, p2, p3, p4, p5, p6, p7, p8);
            }
        }
       
        public static Point3D getPointInLinefromLength(Point3D p1, Point3D p2, double length)
        {
            double x1 = p1.getX();
            double y1 = p1.getY();
            double x2 = p2.getX();
            double y2 = p2.getY();

            double cx = x1;
            double cy = y1;

            double dx;
            double dy;
            double A;
            double b;
            double C;
            double det;
            double t;

            dx = x2 - x1;
            dy = y2 - y1;

            A = dx * dx + dy * dy;
            b = 2 * (dx * (x1 - cx) + dy * (y1 - cy));
            C = (x1 - cx) * (x1 - cx) + (y1 - cy) * (y1 - cy) - length * length;

            det = b * b - 4 * A * C;
            if ((A <= 0.0000001) || (det < 0))
            {
                return null;
            }
            else if (det == 0)
            {
                t = -b / (2 * A);
                return new Point3D(x1 + t * dx, y1 + t * dy, 0);
            }
            else
            {
                t = (-b - Math.Sqrt(det)) / (2 * A);

                return new Point3D(x1 + t * dx, y1 + t * dy, 0);
            }
        }
        public static Point3D rotatePoint(Point3D p, Point3D centerPoint, double theta)
        {
            double radianTheta = theta * Math.PI / 180;
            double resultX = Math.Cos(radianTheta) * (p.getX() - centerPoint.getX()) - Math.Sin(radianTheta) * (p.getY() - centerPoint.getY()) + centerPoint.getX();
            double resultY = Math.Sin(radianTheta) * (p.getX() - centerPoint.getX()) + Math.Cos(radianTheta) * (p.getY() - centerPoint.getY()) + centerPoint.getY();

            return new Point3D(resultX, resultY, 0);
        }
        public List<LinearRing> cubeMaker(Point3D p1, Point3D p2, Point3D p3, Point3D p4, Point3D p5, Point3D p6, Point3D p7, Point3D p8)
        {
            List<Point3D> plist1 = new List<Point3D>();
            plist1.Add(p1);
            plist1.Add(p2);
            plist1.Add(p3);
            plist1.Add(p4);
            plist1.Add(p1);

            List<Point3D> plist1_1 = new List<Point3D>();
            plist1_1.Add(p1);
            plist1_1.Add(p4);
            plist1_1.Add(p3);
            plist1_1.Add(p2);
            plist1_1.Add(p1);

            List<Point3D> plist2 = new List<Point3D>();
            plist2.Add(p5);
            plist2.Add(p6);
            plist2.Add(p7);
            plist2.Add(p8);
            plist2.Add(p5);

            List<Point3D> plist2_1 = new List<Point3D>();
            plist2_1.Add(p5);
            plist2_1.Add(p8);
            plist2_1.Add(p7);
            plist2_1.Add(p6);
            plist2_1.Add(p5);

            List<Point3D> plist3 = new List<Point3D>();
            plist3.Add(p6);
            plist3.Add(p2);
            plist3.Add(p3);
            plist3.Add(p7);
            plist3.Add(p6);

            List<Point3D> plist3_1 = new List<Point3D>();
            plist3_1.Add(p6);
            plist3_1.Add(p7);
            plist3_1.Add(p3);
            plist3_1.Add(p2);
            plist3_1.Add(p6);

            List<Point3D> plist4 = new List<Point3D>();
            plist4.Add(p5);
            plist4.Add(p1);
            plist4.Add(p4);
            plist4.Add(p8);
            plist4.Add(p5);

            List<Point3D> plist4_1 = new List<Point3D>();
            plist4_1.Add(p5);
            plist4_1.Add(p8);
            plist4_1.Add(p4);
            plist4_1.Add(p1);
            plist4_1.Add(p5);

            List<Point3D> plist5 = new List<Point3D>();
            plist5.Add(p6);
            plist5.Add(p2);
            plist5.Add(p1);
            plist5.Add(p5);
            plist5.Add(p6);

            List<Point3D> plist5_1 = new List<Point3D>();
            plist5_1.Add(p6);
            plist5_1.Add(p5);
            plist5_1.Add(p1);
            plist5_1.Add(p2);
            plist5_1.Add(p6);

            List<Point3D> plist6 = new List<Point3D>();
            plist6.Add(p7);
            plist6.Add(p3);
            plist6.Add(p4);
            plist6.Add(p8);
            plist6.Add(p7);

            List<Point3D> plist6_1 = new List<Point3D>();
            plist6_1.Add(p7);
            plist6_1.Add(p8);
            plist6_1.Add(p4);
            plist6_1.Add(p3);
            plist6_1.Add(p7);

            LinearRing l1 = new LinearRing(plist1);
            LinearRing l2 = new LinearRing(plist2);
            LinearRing l3 = new LinearRing(plist3);
            LinearRing l4 = new LinearRing(plist4);
            LinearRing l5 = new LinearRing(plist5);
            LinearRing l6 = new LinearRing(plist6);
            LinearRing l1_1 = new LinearRing(plist1_1);
            LinearRing l2_1 = new LinearRing(plist2_1);
            LinearRing l3_1 = new LinearRing(plist3_1);
            LinearRing l4_1 = new LinearRing(plist4_1);
            LinearRing l5_1 = new LinearRing(plist5_1);
            LinearRing l6_1 = new LinearRing(plist6_1);

            List<LinearRing> result = new List<LinearRing>();
            result.Add(l1);
            result.Add(l2);
            result.Add(l3);
            result.Add(l4);
            result.Add(l5);
            result.Add(l6);
            result.Add(l1_1);
            result.Add(l2_1);
            result.Add(l3_1);
            result.Add(l4_1);
            result.Add(l5_1);
            result.Add(l6_1);

            return result;
        }
    }
}
