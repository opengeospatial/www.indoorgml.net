﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using IFC2IndoorGML.DataType;
using IFC2IndoorGML.Export;

namespace IFC2IndoorGML
{
    public partial class Form1 : Form
    {
       // definite dialog
        public Help.Help help;
        public Help.About about;

        public ReferencePoint.BottomLeftPointForm bottomLeftPointForm;
        public ReferencePoint.TopRightPointForm topRightPointForm;

        public Export.Export exportManager;

        // for boundedBy
        public Point3D lowerCornerPoint;
        public Point3D upperCornerPoint;
        public Point contentCenter;

        // panel's reference points
        public Point3D lowerRP;
        public Point3D upperRP;
        // model's reference points
        public Point3D lowerModelRP;
        public Point3D upperModelRP;

        // variables for network information
        public int selectedIndex;
        public List<double> queryZList;
        public int levelInfo;

        // coordinates list for display at panel
        public List<List<State>> statesAll = new List<List<State>>();   // save states in all level (for display at panel)
        public static List<List<Transition>> transitionsAll = new List<List<Transition>>(); // save transitions in all level (for display at panel)
        public List<State> states = new List<State>(); // save states in current level
        public static List<Transition> transitionsList = new List<Transition>(); // save transitions in current level

        // coordinates list for indoorGML's coordinates
        public List<List<State>> statesAllSBMPoint = new List<List<State>>();   // save states in all level (for indoorGML's coordinates)
        public static List<List<Transition>> transitionsAllSBMPoint = new List<List<Transition>>();  // save transitions in all level (for indoorGML's coordinates)

        // variables for 'move state' or 'create transition'
        public State beforeMoveState;
        public State beforeMoveStateSBM;
        public State floorState1 = null;
        public State floorState2 = null;

        // state Index for network
        public int state_Index = 0;
        public int state1_Index = 0;
        public int state2_Index = 0;
        public int transition_Index = 0;
       
        // import Image
        public Image imgJPG;
        public Bitmap imgBMP;
        public Bitmap resizeBMP;

        // flags
        public bool isSelect;
        public bool isMove;
        public bool isInputBottomLeftPoint;
        public bool isInputTopRightPoint;

        // edit menu select enumeration
        public enum editState { None, CreateState, MoveState, DeleteState, Transition, BottomLeftPoint, TopRightPoint}
        public editState es = editState.None;

        // use double buffering panel to avoid blink
        public class DoubleBufferingPanel : System.Windows.Forms.Panel
        {
            public DoubleBufferingPanel()
            {
                this.SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
                this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
                this.SetStyle(ControlStyles.ResizeRedraw, true);
                this.UpdateStyles();
            }
        }
        // double buffering panel
        public DoubleBufferingPanel panel2;

        // initialize
        public Form1()
        {
            InitializeComponent();

            exportManager = new Export.Export();

            // double buffered panel setting
            panel2 = new DoubleBufferingPanel();
            panel2.BackColor = panel1.BackColor;
            panel2.BorderStyle = panel1.BorderStyle;
            panel2.Controls.Add(statusStrip1);
            panel2.Enabled = false;
            panel2.Location = panel1.Location;
            panel2.Name = "panel2";
            panel2.Size = panel1.Size;
            panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            panel2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
            panel2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            panel2.Parent = this;

            // set default corner points
            lowerCornerPoint = new Point3D(-100, -100, -100);
            upperCornerPoint = new Point3D(100, 100, 100);
            contentCenter = GetContentsCenter(lowerCornerPoint, upperCornerPoint);

            // flags
            isSelect = false;
            isMove = false;
            isInputBottomLeftPoint = false;
            isInputTopRightPoint = false;
            exportToolStripMenuItem.Enabled = false;

        }

        // set Model's bottomLeftPoint
        public void SetBottomLeftPoint(Point3D p3){
            lowerModelRP = new Point3D(p3.getX(), p3.getY(), p3.getZ());
            queryZList[0] = p3.getZ();
            //lowerCornerPoint = new Point3D(p3.getX() - Math.Abs(p3.getX() / 10), p3.getY() - Math.Abs(p3.getY() / 10), p3.getZ() - Math.Abs(p3.getZ() / 10));

            isInputBottomLeftPoint = true;
            if (isInputBottomLeftPoint && isInputTopRightPoint)
            {
                this.createStateToolStripMenuItem.Enabled = true;
                this.moveStateToolStripMenuItem.Enabled = true;
                this.deleteStateToolStripMenuItem.Enabled = true;
                this.createTransitionToolStripMenuItem.Enabled = true;

                this.toolStripButton1.Enabled = true;
                this.toolStripButton2.Enabled = true;
                this.toolStripButton3.Enabled = true;
                this.toolStripButton4.Enabled = true;
            }
        }
        // set Model's topRightPoint
        public void SetTopRightPoint(Point3D p3)
        {
            upperModelRP = new Point3D(p3.getX(), p3.getY(), p3.getZ());
            queryZList[0] = p3.getZ();
            //upperCornerPoint = new Point3D(p3.getX() + Math.Abs(p3.getX() / 10), p3.getY() + Math.Abs(p3.getY() / 10), p3.getZ() + Math.Abs(p3.getZ() / 10));

            isInputTopRightPoint = true;
            if (isInputBottomLeftPoint && isInputTopRightPoint)
            {
                this.createStateToolStripMenuItem.Enabled = true;
                this.moveStateToolStripMenuItem.Enabled = true;
                this.deleteStateToolStripMenuItem.Enabled = true;
                this.createTransitionToolStripMenuItem.Enabled = true;

                this.toolStripButton1.Enabled = true;
                this.toolStripButton2.Enabled = true;
                this.toolStripButton3.Enabled = true;
                this.toolStripButton4.Enabled = true;
            }
        }

        // panel paint & refresh
        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            Graphics gp = e.Graphics;

            if (levelInfo > 0)
            {
                if (!isSelect)
                {
                    // draw Transitions
                    foreach (Transition t in transitionsAll[selectedIndex])
                    {
                        Point[] p = new Point[2];
                        p[0] = TransitionToCenter(point3DToDisplayPoint(t.state1.point, lowerCornerPoint, upperCornerPoint, panel2.Width, panel2.Height));
                        p[1] = TransitionToCenter(point3DToDisplayPoint(t.state2.point, lowerCornerPoint, upperCornerPoint, panel2.Width, panel2.Height));
                        gp.DrawLines(new Pen(Color.Red, 3), p);
                    }

                    // draw States
                    foreach (State st in statesAll[selectedIndex])
                    {
                        int radius = 2;
                        int xValue = TransitionToCenter(point3DToDisplayPoint(st.point, lowerCornerPoint, upperCornerPoint, panel2.Width, panel2.Height)).X - radius;
                        int yValue = TransitionToCenter(point3DToDisplayPoint(st.point, lowerCornerPoint, upperCornerPoint, panel2.Width, panel2.Height)).Y - radius;
                        int diam = radius * 2;

                        if(st.isFloorToFloor)
                            gp.DrawEllipse(new Pen(Color.Purple, 20), xValue, yValue, diam, diam);
                        
                        if(st.stateInfo.spaceType == "Door")
                            gp.DrawEllipse(new Pen(Color.Green, 4), xValue, yValue, diam, diam);
                        else
                            gp.DrawEllipse(new Pen(Color.Blue, 4), xValue, yValue, diam, diam);
                    }
                }
            }
        }

        // Point3D to Point for display at panel
        public List<List<List<Point>>> ConvertPointtoDisplay(List<List<List<Point3D>>> data)
        {

            List<List<List<Point>>> result = new List<List<List<Point>>>();
            for (int i = 0; i < levelInfo; i++)
            {
                List<List<Point>> tempDisplayListListPoint = new List<List<Point>>();
                foreach (List<Point3D> lp in data[i])
                {
                    List<Point> tempDisplayListPoint = new List<Point>();
                    foreach (Point3D p3 in lp)
                    {
                        
                        Point tempPoint = point3DToDisplayPoint(p3, lowerCornerPoint, upperCornerPoint, panel2.Width, panel2.Height);
                        Point resultPoint = TransitionToCenter(tempPoint);
                        Point resultPoint2 = new Point(Math.Abs(resultPoint.X), Math.Abs(resultPoint.Y));
                        tempDisplayListPoint.Add(resultPoint2);
                    }
                    tempDisplayListListPoint.Add(tempDisplayListPoint);
                }
                result.Add(tempDisplayListListPoint);
            }

            return result;
        }
        
        // Display Point to Point3D
        public Point point3DToDisplayPoint(Point3D point, Point3D lowerCornerPoint, Point3D upperCornerPoint, int panelWidth, int panelHeight)
        {
            // display scale
            double scale = 1;

            double width = Math.Abs(lowerCornerPoint.getX() - upperCornerPoint.getX()) * scale;
            double height = Math.Abs(lowerCornerPoint.getY() - upperCornerPoint.getY()) * scale;

            double scaleX = panelWidth / (double)width;
            double scaleY = panelHeight / (double)height;

            Point result = new Point((int)((point.getX() - lowerCornerPoint.getX()) * scaleX), panelHeight - (int)(((point.getY() - lowerCornerPoint.getY()) * scaleY)));
            return result;
        }
        // Point3D to Display Point
        public Point3D displayPointToPoint3D(Point point, Point3D lowerCornerPoint, Point3D upperCornerPoint, int panelWidth, int panelHeight)
        {
            // display scale
            double scale = 1;

            double width = Math.Abs(lowerCornerPoint.getX() - upperCornerPoint.getX()) * scale;
            double height = Math.Abs(lowerCornerPoint.getY() - upperCornerPoint.getY()) * scale;

            double scaleX = (double)width / panelWidth;
            double scaleY = (double)height / panelHeight;

            Point3D result = new Point3D(lowerCornerPoint.getX() + (point.X * scaleX), lowerCornerPoint.getY() - (point.Y - panelHeight) * scaleY, queryZList[selectedIndex]);
          
            return result;
        }

        public Point GetContentsCenter(Point3D lowerCorenr, Point3D upperCorner)
        {
            double centerX = (Math.Abs(lowerCorenr.getX() - upperCorner.getX()) / 2) + lowerCorenr.getX();
            double centerY = (Math.Abs(lowerCorenr.getY() - upperCorner.getY()) / 2) + lowerCorenr.getY();

            Point3D centerCoor = new Point3D(centerX, centerY, 0);

            Point result = point3DToDisplayPoint(centerCoor, lowerCornerPoint, upperCornerPoint, panel2.Width, panel2.Height);
            return result;
        }
        public Point TransitionToCenter(Point p)
        {
            double panelCenterX = panel2.Width / 2;
            double panelCenterY = panel2.Height / 2;

            double transitionX = Math.Abs(contentCenter.X - panelCenterX);
            double transitionY = Math.Abs(contentCenter.Y - panelCenterY);

            Point result = new Point(p.X + (int)transitionX, p.Y - (int)transitionY);
            return result;
        }
        public Point TransitionToOriginal(Point p)
        {
            double panelCenterX = panel2.Width / 2;
            double panelCenterY = panel2.Height / 2;

            double transitionX = Math.Abs(contentCenter.X - panelCenterX);
            double transitionY = Math.Abs(contentCenter.Y - panelCenterY);

            Point result = new Point(p.X - (int)transitionX, p.Y + (int)transitionY);
            return result;
        }
        public void IsFloorToFloor()
        {
            foreach (List<Transition> lt in transitionsAll)
            {
                foreach (Transition t in lt)
                {

                    if (t.state1.floor != t.state2.floor)
                    {

                        // for state1
                        foreach (State s in statesAll[t.state1.floor])
                        {
                            if (s.point.getX() == t.state1.point.getX() && s.point.getY() == t.state1.point.getY())
                            {
                                s.isFloorToFloor = true;
                                break;
                            }
                        }

                        // for state2
                        foreach (State s in statesAll[t.state2.floor])
                        {
                            if (s.point.getX() == t.state2.point.getX() && s.point.getY() == t.state2.point.getY())
                            {
                                s.isFloorToFloor = true;
                                break;
                            }
                        }
                    }

                }

            }
        }
       
        // check the point in polygon
        public bool IsInPolygon(List<Point3D> poly, Point3D p)
        {
            bool isInside = false;

            Point3D p1, p2;
            Point3D oldPoint = new Point3D(poly[poly.Count - 1].getX(), poly[poly.Count - 1].getY(), 0);
            if (poly.Count < 3)
                return isInside;

            for (int i = 0; i < poly.Count; i++)
            {
                Point3D newPoint = new Point3D(poly[i].getX(), poly[i].getY(), 0);

                if (newPoint.getX() > oldPoint.getX())
                {
                    p1 = oldPoint;
                    p2 = newPoint;
                }

                else
                {
                    p1 = newPoint;
                    p2 = oldPoint;
                }

                if ((newPoint.getX() < p.getX()) == (p.getX() <= oldPoint.getX())
                    && (p.getY() - (double)p1.getY()) * (p2.getX() - p1.getX())
                    < (p2.getY() - (double)p1.getY()) * (p.getX() - p1.getX()))
                {
                    isInside = !isInside;
                }

                oldPoint = newPoint;
            }
            return isInside;
        }
    
        // convert coordinates for model (panel's coordinates -> model's coordinates(IndoorGML's coordinates))
        public Point3D GetSBMPoint(Point3D p3)
        {
            double firstSubX = Math.Abs(p3.getX() - lowerRP.getX());
            double firstSubY = Math.Abs(p3.getY() - lowerRP.getY());

            double secondSubX = Math.Abs(upperRP.getX() - lowerRP.getX());
            double secondSubY = Math.Abs(upperRP.getY() - lowerRP.getY());

            double pnuSubX = Math.Abs(upperModelRP.getX() - lowerModelRP.getX());
            double pnuSubY = Math.Abs(upperModelRP.getY() - lowerModelRP.getY());

            double resultPointX = lowerModelRP.getX() + (pnuSubX * firstSubX / secondSubX);
            double resultPointY = lowerModelRP.getY() + (pnuSubY * firstSubY / secondSubY);

            Point3D result = new Point3D(resultPointX, resultPointY, queryZList[selectedIndex]);

            return result;
        }

        // click event(under)
        // Edit menu select
        private void createStateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            es = editState.CreateState;
        }
        private void moveStateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            es = editState.MoveState;
        }
        private void deleteStateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            es = editState.DeleteState;
        }
        private void createTransitionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            es = editState.Transition;
        }
        private void bottomLeftPointToolStripMenuItem_Click(object sender, EventArgs e)
        {
            es = editState.BottomLeftPoint;
        }
        private void topRightPointToolStripMenuItem_Click(object sender, EventArgs e)
        {
            es = editState.TopRightPoint;
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            es = editState.CreateState;
        }
        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            es = editState.MoveState;
        }
        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            es = editState.DeleteState;
        }
        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            es = editState.Transition;
        }
        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            es = editState.BottomLeftPoint;
        }
        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            es = editState.TopRightPoint;
        }

        // panel mouse down
        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {

            Point3D currentPoint = displayPointToPoint3D(new Point(e.X, e.Y), lowerCornerPoint, upperCornerPoint, panel2.Width, panel2.Height);
            //Console.WriteLine(currentPoint.getX() + "/" + currentPoint.getY());
            // make point's buffer area 
            int bufferPixel = 10;
            Point3D leftTop = displayPointToPoint3D(new Point(e.X - bufferPixel / 2, e.Y + bufferPixel / 2), lowerCornerPoint, upperCornerPoint, panel2.Width, panel2.Height);
            Point3D leftBottom = displayPointToPoint3D(new Point(e.X - bufferPixel / 2, e.Y - bufferPixel / 2), lowerCornerPoint, upperCornerPoint, panel2.Width, panel2.Height);
            Point3D rightBottom = displayPointToPoint3D(new Point(e.X + bufferPixel / 2, e.Y - bufferPixel / 2), lowerCornerPoint, upperCornerPoint, panel2.Width, panel2.Height);
            Point3D rightTop = displayPointToPoint3D(new Point(e.X + bufferPixel / 2, e.Y + bufferPixel / 2), lowerCornerPoint, upperCornerPoint, panel2.Width, panel2.Height);

            List<Point3D> rect = new List<Point3D>();
            rect.Add(leftTop);
            rect.Add(leftBottom);
            rect.Add(rightBottom);
            rect.Add(rightTop);

            
            if (es == editState.CreateState)
            {
                // Create State
                StateInfo tempStateInfo = new StateInfo();
                
                tempStateInfo.spaceType = "Cell";
                tempStateInfo.objectName = "ST" + state_Index.ToString();
                tempStateInfo.objectIndex = state_Index;
                state_Index++;

                // coordinates for display (panel)
                statesAll[selectedIndex].Add(new State(tempStateInfo, currentPoint, selectedIndex));

                // coordinates for model (IndoorGML file)
                Point3D sbmPoint = GetSBMPoint(currentPoint);
                statesAllSBMPoint[selectedIndex].Add(new State(tempStateInfo, sbmPoint, selectedIndex));

                panel2.Refresh();
            }
            else if(es == editState.MoveState)
            {
                // Move State
                beforeMoveState = new State();
                beforeMoveStateSBM = new State();
                for (int i = 0; i < statesAll[selectedIndex].Count; i++)
                {
                    if (IsInPolygon(rect, statesAll[selectedIndex][i].point))
                    {
                        beforeMoveState = statesAll[selectedIndex][i];
                        statesAll[selectedIndex].Remove(statesAll[selectedIndex][i]);

                        beforeMoveStateSBM = statesAllSBMPoint[selectedIndex][i];
                        statesAllSBMPoint[selectedIndex].Remove(statesAllSBMPoint[selectedIndex][i]);
                        isMove = true;
                        break;
                    }
                }
            }
            else if(es == editState.DeleteState)
            {
                // Delete State

                for (int i = 0; i < statesAll[selectedIndex].Count; i++)
                {
                    State tempState = statesAll[selectedIndex][i];

                    if (IsInPolygon(rect, tempState.point))
                    {
                        for (int j = 0; j < transitionsAll.Count; j++)
                        {
                            for (int k = 0; k < transitionsAll[j].Count; k++)
                            {
                                Transition tempTransition = transitionsAll[j][k];
                                if (tempTransition.state1.stateInfo.objectName == tempState.stateInfo.objectName || tempTransition.state2.stateInfo.objectName == tempState.stateInfo.objectName)
                                {
                                    transitionsAll[j].Remove(transitionsAll[j][k]);
                                    transitionsAllSBMPoint[j].Remove(transitionsAllSBMPoint[j][k]);
                                    k--;
                                    continue;
                                }
                            }
                        }

                        statesAll[selectedIndex].Remove(statesAll[selectedIndex][i]);
                        statesAllSBMPoint[selectedIndex].Remove(statesAllSBMPoint[selectedIndex][i]);
                        break;
                    }
                }
                panel2.Refresh();
            }
            else if(es == editState.Transition)
            {
                // Create Transition
                if (floorState1 == null)
                {
                    for (int i = 0; i < statesAll[selectedIndex].Count; i++)
                    {
                        if (IsInPolygon(rect, statesAll[selectedIndex][i].point))
                        {
                            floorState1 = statesAll[selectedIndex][i];
                            state1_Index = i;
                            break;
                        }
                    }
                }
                else if (floorState1 != null)
                {                  
                    for (int i = 0; i < statesAll[selectedIndex].Count; i++)
                    {
                        if (IsInPolygon(rect, statesAll[selectedIndex][i].point))
                        {
                            floorState2 = statesAll[selectedIndex][i];
                            state2_Index = i;
                            break;
                        }
                    }

                    if (floorState2 != null)
                    {
                        Transition tran = new Transition();
                        if (floorState1 != null && floorState2 != null)
                        {
                            TransitionInfo tempTransitionInfo = new TransitionInfo();

                            tempTransitionInfo.objectIndex = transition_Index;
                            tempTransitionInfo.objectName = "TR" + floorState1.stateInfo.objectIndex.ToString() + "_" + floorState2.stateInfo.objectIndex.ToString();

                            transitionsAll[selectedIndex].Add(new Transition(tempTransitionInfo, floorState1, floorState2));    // floorState2's floor // 현재 Index
                            transitionsAllSBMPoint[selectedIndex].Add(new Transition(tempTransitionInfo, statesAllSBMPoint[selectedIndex][state1_Index], statesAllSBMPoint[selectedIndex][state2_Index])); 
                           
                            transition_Index++;
                        }
                    }

                    // delete floorState 
                    state1_Index = 0;
                    state2_Index = 0;
                    floorState1 = null;
                    floorState2 = null;
                    panel2.Refresh();
                }
            }
            else if (es == editState.BottomLeftPoint)
            {
                // set panel's coordinates to lowerRP
                bottomLeftPointForm = new ReferencePoint.BottomLeftPointForm(this);
                lowerRP = new Point3D(currentPoint.getX(), currentPoint.getY(), 1);
                bottomLeftPointForm.Show();
            }
            else if (es == editState.TopRightPoint)
            {
                topRightPointForm = new ReferencePoint.TopRightPointForm(this);
                upperRP = new Point3D(currentPoint.getX(), currentPoint.getY(), 1);
                topRightPointForm.Show();
            }
        }

        // panel mouse up
        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            
            Point3D currentPoint = displayPointToPoint3D(new Point(e.X, e.Y), lowerCornerPoint, upperCornerPoint, panel2.Width, panel2.Height);

            if (es == editState.MoveState)
            {
                if (isMove)
                {   
                    State newState = new State(beforeMoveState.stateInfo, currentPoint, selectedIndex);
                    statesAll[selectedIndex].Add(newState);

                    // coordinates for model (IndoorGML file)
                    Point3D sbmPoint = GetSBMPoint(currentPoint);
                    State newStateSBM = new State(beforeMoveStateSBM.stateInfo, sbmPoint, selectedIndex);
                    statesAllSBMPoint[selectedIndex].Add(newStateSBM);

                    // update transition's updated state
                    for (int i = 0; i < transitionsAll[selectedIndex].Count; i++)
                    {
                        Transition tempTransition = transitionsAll[selectedIndex][i];
                        if (tempTransition.state1.stateInfo.objectName == beforeMoveState.stateInfo.objectName)
                        {
                            transitionsAll[selectedIndex][i].state1 = newState;
                            transitionsAllSBMPoint[selectedIndex][i].state1 = newStateSBM;
                            continue;
                        }
                        // state2
                        if (tempTransition.state2.stateInfo.objectName == beforeMoveState.stateInfo.objectName)
                        {
                            transitionsAll[selectedIndex][i].state2 = newState;
                            transitionsAllSBMPoint[selectedIndex][i].state2 = newStateSBM;
                            continue;
                        }
                    }

                    isMove = false;
                    panel2.Refresh();
                    
                }
            }

        }

        // import image file for base map
        private void imageJPGToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "Image Files(*.jpg; *jpeg; *png)|*.jpg; *jpeg; *png";
            open.InitialDirectory = @"C:\";
            open.Title = "Open";

            String filePath = "";
            // load image file
            if (open.ShowDialog() == DialogResult.OK)
            {
                
                filePath = open.FileName;

                imgBMP = new Bitmap(filePath);
                resizeBMP = new Bitmap(panel2.Width, panel2.Height);
                using (Graphics g = Graphics.FromImage((Image)resizeBMP))
                    g.DrawImage(imgBMP, panel2.Width * 1 / 8, panel2.Height * 1 / 8, panel2.Width * 3 / 4, panel2.Height * 3 / 4);

                // set default corner points
                lowerCornerPoint = new Point3D(-100, -100, -100);
                upperCornerPoint = new Point3D(100, 100, 100);
                contentCenter = GetContentsCenter(lowerCornerPoint, upperCornerPoint);

                queryZList = new List<double>();
                queryZList.Add(1);
                levelInfo = queryZList.Count;
                selectedIndex = 0;

                // initialize
                statesAll.Clear();
                statesAllSBMPoint.Clear();
                transitionsAll.Clear();
                transitionsAllSBMPoint.Clear();

                // create dummy for null states & transitions
                for (int i = 0; i < levelInfo; i++)
                {
                    List<State> dummyState = new List<State>();
                    List<State> dummyState2 = new List<State>();
                    statesAll.Add(dummyState);
                    statesAllSBMPoint.Add(dummyState2);

                    List<Transition> dummyTransition = new List<Transition>();
                    List<Transition> dummyTransition2 = new List<Transition>();
                    transitionsAll.Add(dummyTransition);
                    transitionsAllSBMPoint.Add(dummyTransition2);
                }

                this.exportToolStripMenuItem.Enabled = true;
                this.createReferencePointsToolStripMenuItem.Enabled = true;
                this.toolStripButton5.Enabled = true;
                this.toolStripButton6.Enabled = true;

                this.createStateToolStripMenuItem.Enabled = false;
                this.moveStateToolStripMenuItem.Enabled = false;
                this.deleteStateToolStripMenuItem.Enabled = false;
                this.createTransitionToolStripMenuItem.Enabled = false;

                this.toolStripButton1.Enabled = false;
                this.toolStripButton2.Enabled = false;
                this.toolStripButton3.Enabled = false;
                this.toolStripButton4.Enabled = false;

                isInputBottomLeftPoint = false;
                isInputTopRightPoint = false;

                panel2.Enabled = true;
                panel2.BackgroundImage = resizeBMP;
                 
            }
        }

        // export IndoorGML file
        private void indoorGMLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                SaveFileDialog save = new SaveFileDialog();
                save.Filter = "indoorgml file(*gml)|*.gml";
                save.Title = "Save";

                String filePath = "";
                BoundedBy boundedBy = new BoundedBy(lowerCornerPoint, upperCornerPoint);
                if (save.ShowDialog() == DialogResult.OK)
                {
                    if (save.FileName != "")
                    {
                        filePath = save.FileName;
                        exportManager.ExportIndoorGML(filePath, boundedBy, statesAllSBMPoint, transitionsAllSBMPoint);
                        //exportManager.ExportIndoorGML(filePath, boundedBy, statesAll, transitionsAll, listRooms);
                        MessageBox.Show("indoorgml export success!!");
                    }
                }
            }
            catch
            {
                MessageBox.Show("Export failed");
            }
        }

        // export CityGML file
        private void cityGMLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                SaveFileDialog save = new SaveFileDialog();
                save.Filter = "citygml file(*gml)|*.gml";
                save.Title = "Save";

                String filePath = "";
                if (save.ShowDialog() == DialogResult.OK)
                {
                    if (save.FileName != "")
                    {
                        filePath = save.FileName;
                        exportManager.ExportCityGML(filePath, statesAll, transitionsAll);
                        MessageBox.Show("citygml export success!!");
                    }
                }
            }
            catch
            {
                MessageBox.Show("Export failed");
            }
        }

        // exit program
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch
            {
                MessageBox.Show("Failed");
            }
        }

        private void helpToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            help = new Help.Help();
            help.Show();
        }
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            about = new Help.About();
            about.Show();
        }

    }
}