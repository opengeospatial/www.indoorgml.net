﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IFC2IndoorGML.DataType
{
    public class Point3D
    {
        double X { get; set; }
        double Y { get; set; }
        double Z { get; set; }

        public Point3D(double X, double Y, double Z)
        {
            this.X = X;
            this.Y = Y;
            this.Z = Z;
        }

        public double getX(){
            return X;
        }

        public double getY()
        {
            return Y;
        }

        public double getZ()
        {
            return Z;
        }

    }
}
