﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace IFC2IndoorGML.DataType
{
    public class Surface
    {
        public String roomName;
        public String surfaceType;
        public List<Point3D> pointList = new List<Point3D>();
        public List<Point> pointList2D = new List<Point>();

        public Surface(String roomName, String surfaceType, List<Point3D> pointList)
        {
            this.roomName = roomName;
            this.surfaceType = surfaceType;
            this.pointList = pointList;
        }

    }
}
