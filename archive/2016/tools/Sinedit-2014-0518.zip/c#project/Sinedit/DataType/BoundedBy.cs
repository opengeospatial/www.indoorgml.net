﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IFC2IndoorGML.DataType
{
    public class BoundedBy
    {
        public Point3D lowerCornerPoint;
        public Point3D upperCornerPoint;

        public BoundedBy(Point3D lowerCornerPoint, Point3D upperCornerPoint)
        {
            this.lowerCornerPoint = lowerCornerPoint;
            this.upperCornerPoint = upperCornerPoint;
        }
    }
}
