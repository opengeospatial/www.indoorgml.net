﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IFC2IndoorGML.DataType
{
    public class State
    {
        // cell Information
        public StateInfo stateInfo;

        public Point3D point;
        public int floor;
        public List<Transition> connects;

        public bool isFloorToFloor;

        public State()
        {
            isFloorToFloor = false;
            connects = new List<Transition>();
        }

        public State(StateInfo stateInfo, Point3D point, int floor)
        {
            this.stateInfo = stateInfo;
            this.point = point;
            this.floor = floor;
        }
    }

    public class StateInfo
    {
        // cell Information
        public String objectName;
        public int objectIndex;
        public String spaceType;
    }
}
