﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IFC2IndoorGML.DataType
{
    public class Transition
    {

        public State state1;
        public State state2;

        public TransitionInfo transitionInfo;

        public Transition() { }
     
        public Transition(TransitionInfo transitionInfo, State state1, State state2)
        {
            this.transitionInfo = transitionInfo;
            this.state1 = state1;
            this.state2 = state2;
        }
    }

    public class TransitionInfo
    {
        public String objectName;
        public int objectIndex;
    }

}
