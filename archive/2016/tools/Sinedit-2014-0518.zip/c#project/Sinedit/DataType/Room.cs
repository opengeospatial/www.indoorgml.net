﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IFC2IndoorGML.DataType
{
    public class Room
    {

        public String roomName;
        public long level;
        public List<Surface> surfaceList;

        public Room(){
            surfaceList = new List<Surface>();
        }

    }
}
