﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IFC2IndoorGML.DataType
{
    public class LinearRing
    {
        public List<Point3D> pointList;

        public LinearRing(List<Point3D> point)
        {
            this.pointList = point;
        }
        public LinearRing()
        {

        }
        public override string ToString()
        {
            StringBuilder result = new StringBuilder();
            for (int i = 0; i < pointList.Count; i++)
            {
                int c = pointList.Count - 1;
                if (i == c)
                {
                    result.Append(pointList[i].getX() + " " + pointList[i].getY() + " " + pointList[i].getZ());
                }
                else
                {
                    result.Append(pointList[i].getX() + " " + pointList[i].getY() + " " + pointList[i].getZ() + " ");
                }
            }
            return result.ToString();
        }
    }
}
