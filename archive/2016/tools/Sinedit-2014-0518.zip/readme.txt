Step
1. Open Sinedit program
2. Choose 2D map image file(File - Import - Image(JPG))
3. Set reference points include bottom left point(BL) and top right point(TR)
   (you can choose icons in menu bar(BL, TR) or Edit - Create Reference Points - Bottom Left Point, Top Right Point) 
4. Create State and Transition (edit network)
5. Export IndoorGML file (File - Export - IndoorGML)
